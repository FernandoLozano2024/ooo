for (var i=1;i<=5;i++) { 
    document.write("<H" + i + ">hola " + i + "</H" + i + ">") 
}