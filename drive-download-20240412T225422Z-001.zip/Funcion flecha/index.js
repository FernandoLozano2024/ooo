var colores = ['verde','azul','rojo','amarillo','blanco'];
/*for(var i=0; i< colores.length; i++){
    
}*/

//colores.forEach(c=>{console.log(c)});

function suma(n1,n2){
return n1 + n2;
}
const sumaf =(n1,n2) => {
    return n1+n2;
}
const sumaff=(n1,n2) => n1+n2;


const cuad = c => c*c;

console.log (sumaff(5,7));
